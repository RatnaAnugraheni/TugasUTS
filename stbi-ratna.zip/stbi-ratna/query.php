<html>
<div align="center"><b><h1>PENCARIAN QUERY </h1></b>
<form enctype="multipart/form-data" method="POST" action="?menu=hasilquery">
Masukan Keyword : <br><p>
<input type="text" name="katakunci">
<input type="submit" value= "submit">
<body>
</form>
</div>
</body>
</html>