<!DOCTYPE html>
<html>
<title>STBI-UNISBANK</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<div class="w3-container">
  <h1 align="center">STBI</h1>
  <p align="center">Sistem Temu Balik Informasi</p>

  <div class="w3-bar w3-light-grey">
    <a href="?menu=home" class="w3-bar-item w3-button w3-green">Home</a>    
    <div class="w3-dropdown-hover">
      <button class="w3-button w3-green">Menu</button>
      <div class="w3-dropdown-content w3-bar-block w3-card-4">
        <a href="?menu=upload" class="w3-bar-item w3-button">Upload</a>
        <a href="?menu=stem" class="w3-bar-item w3-button">Kata Dasar</a>
        <a href="?menu=query" class="w3-bar-item w3-button">Query</a>
		<a href="?menu=hitungbobot" class="w3-bar-item w3-button">Hitung Bobot</a>
        <a href="?menu=hitungbobot" class="w3-bar-item w3-button">Hitung Vektor</a>
        <a href="?menu=awalquery" class="w3-bar-item w3-button">Query tf.idf</a>
		<a href="?menu=download" class="w3-bar-item w3-button">Download</a>
      </div>
    </div>
	  <a href="?menu=profil" class="w3-bar-item w3-button w3-green">Creator By</a>
  </div>
  <?php
				error_reporting(0);
				if($_GET[menu]=='')
					{
					include('home.php');
					}
				else
					{
					include($_GET[menu].'.php');
					}
	?>
</div>
<!-- Footer -->
<footer class="w3-container w3-padding-64 w3-light-grey w3-center w3-large"> 
  <i class="fa fa-facebook-official w3-hover-opacity"></i>
  <i class="fa fa-instagram w3-hover-opacity"></i>
  <i class="fa fa-snapchat w3-hover-opacity"></i>
  <i class="fa fa-pinterest-p w3-hover-opacity"></i>
  <i class="fa fa-twitter w3-hover-opacity"></i>
  <i class="fa fa-linkedin w3-hover-opacity"></i>
  <p>Created by <a href="https://www.w3schools.com/w3css/default.asp" target="_blank" class="w3-hover-text-green">A.rtn</a></p>
</footer>
</body>
</html>
