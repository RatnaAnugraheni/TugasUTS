<div><p>
Sistem temu kembali informasi berasal dari kata Information Retrieval System (IRS).
Temu kembali informasi adalah sebuah media layanan bagi pengguna untuk memperoleh informasi atau sumber informasi
yang dibutuhkan oleh pengguna. Sistem temu kembali informasi merupakan sistem informasi yang berfungsi untuk menemukan
informasi yang relevan dengan kebutuhan pemakai. Sistem temu kembali informasi berfungsi sebagai perantara kebutuhan
informasi pengguna dengan sumber informasi yang tersedia. Pengertian yang sama mengenai sistem temu kembali informasi
menurut Sulistyo-Basuki sistem temu kembali informasi adalah kegiatan yang bertujuan untuk menyediakan dan memasok
informasi bagi pemakai sebagai jawaban atas permintaan atau berdasarkan kebutuhan pemakai.</p>
    </div>