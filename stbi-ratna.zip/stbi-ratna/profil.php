<div>
Nama : Sri Lestari Ratna Anugraheni<br>
NIM : 14.01.55.0046<br>
Progdi : Sistem Informasi<br>
B1-Pagi
</div>