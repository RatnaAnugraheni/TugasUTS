<html>
<title>Form Upload</title>
<div align="center"><b><h3>Pencarian Query tf.idf</h3></b>
<form enctype="multipart/form-data" method="POST" action="?menu=querytf2">
Kata Kunci : <br>
<input type="text" name="keyword">
<input type=submit value=Submit>
</form>